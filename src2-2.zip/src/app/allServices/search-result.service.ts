import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SearchResultService {

  constructor() { }

  getsearchData(){
    return [
      {
        title: "Search Title One",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Two",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Three",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Four",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Five",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Six",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Seven",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Eight",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Nine",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      },
      {
        title: "Search Title Ten",
        drescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quaerat recusandae rem illo, dignissimos facilis fugiat vel labore explicabo reprehenderit deserunt maxime eaque iste voluptatem architecto iure pariatur aliquid eligendi!"
      }
    ]
  }
}
