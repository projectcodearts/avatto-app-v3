import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligiblity-page-details',
  templateUrl: './eligiblity-page-details.page.html',
  styleUrls: ['./eligiblity-page-details.page.scss'],
})
export class EligiblityPageDetailsPage implements OnInit {
  title: string = "Eligiblity Details";
  constructor() { }

  ngOnInit() {
  }

}
