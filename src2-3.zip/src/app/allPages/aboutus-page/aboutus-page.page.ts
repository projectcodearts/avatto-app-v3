import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus-page',
  templateUrl: './aboutus-page.page.html',
  styleUrls: ['./aboutus-page.page.scss'],
})
export class AboutusPagePage implements OnInit {
  title:string="About Us";
  constructor() { }

  ngOnInit() {
  }

}
