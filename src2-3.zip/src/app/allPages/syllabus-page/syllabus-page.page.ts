import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-syllabus-page',
  templateUrl: './syllabus-page.page.html',
  styleUrls: ['./syllabus-page.page.scss'],
})
export class SyllabusPagePage implements OnInit {

  title:string = "Syllabus";
  constructor() { }

  ngOnInit() {
  }

}
