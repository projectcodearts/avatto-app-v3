import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
/*import { LottieSplashScreen } from '@ionic-native/lottie-splash-screen/ngx';*/
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { CommonService } from './allServices/common.service';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { EntrypointComponent } from './components/entrypoint/entrypoint.component';

import { MenuComponent } from './components/shared/header/menu/menu.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { IonicStorageModule } from '@ionic/storage';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { File } from '@ionic-native/File/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { OneSignal } from '@ionic-native/onesignal/ngx';
import { SyllabusDetailsComponent } from './components/syllabus-details/syllabus-details.component';
import { SyllabusComponent } from './components/syllabus/syllabus.component';
import { StudyMaterialsComponent } from './components/study-materials/study-materials.component';
import { StudyMaterialTableComponent } from './components/study-materials/study-material-table/study-material-table.component';
import { ShortquestionsComponent } from './components/shortquestions/shortquestions.component';
import { ShortitemComponent } from './components/shortquestions/shortitem/shortitem.component';
import { ShortQuestionListingComponent } from './components/shortquestions/listing/short-question-listing/short-question-listing.component';
import { ShortQuestionDetailsComponent } from './components/short-question-details/short-question-details.component';
import { SearchbarComponent } from './components/searchbar/searchbar.component';
import { SearchResultComponent } from './components/search-result/search-result.component';
import { ResultComponent } from './components/result/result.component';
import { ViewResultComponent } from './components/result/view-result/view-result.component';
import { RegisterComponent } from './components/register/register.component';
import { QuizMainComponent } from './components/quiz-main/quiz-main.component';
import { QuizComponent } from './components/quiz/quiz.component';
import { ViewQuizComponent } from './components/quiz/view-quiz/view-quiz.component';
import { AllQuizComponent } from './components/quiz/all-quiz/all-quiz.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ProductsComponent } from './components/products/products.component';
import { ProductItemComponent } from './components/products/product-item/product-item.component';
import { ProductDetailsComponent } from './components/products/product-details/product-details.component';
import { FilterComponent } from './components/products/filter/filter.component';
import { FiltercategoryComponent } from './components/products/filter/filtercategory/filtercategory.component';
import { FilterItemComponent } from './components/products/filter/filtercategory/filter-item/filter-item.component';
import { PracticeQuizListingComponent } from './components/practice-quiz-listing/practice-quiz-listing.component';
import { PracticeQuizComponent } from './components/practice-quiz/practice-quiz.component';
import { PracticeQuestionDetailsComponent } from './components/practice-question-details/practice-question-details.component';
import { PracticeQuestionComponent } from './components/practice-question/practice-question.component';
import { PapersComponent } from './components/papers/papers.component';
import { PapersTableComponent } from './components/papers/papers-table/papers-table.component';
import { AllPapersComponent } from './components/papers/all-papers/all-papers.component';
import { OrdersComponent } from './components/orders/orders.component';
import { NotfoundComponent } from './components/notfound/notfound.component';
import { MocktestComponent } from './components/mocktest/mocktest.component';
import { McqComponent } from './components/mcq/mcq.component';
import { McqItemComponent } from './components/mcq/mcq-item/mcq-item.component';
import { LoginComponent } from './components/login/login.component';
import { FeaturedCategoryComponent } from './components/featured-category/featured-category.component';
import { EligiblityComponent } from './components/eligiblity/eligiblity.component';
import { EligiblityDetailsComponent } from './components/eligiblity/eligiblity-details/eligiblity-details.component';
import { AllEligiblityComponent } from './components/eligiblity/all-eligiblity/all-eligiblity.component';
import { CouponComponent } from './components/coupon/coupon.component';
import { CheckoutCouponComponent } from './components/checkout-coupon/checkout-coupon.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { CartComponent } from './components/cart/cart.component';
import { AllcategoriesComponent } from './components/allcategories/allcategories.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { SharedModuleModule } from './sharedModule/shared-module/shared-module.module';



@NgModule({
  declarations: [
    AppComponent, 
    HeaderComponent, 
    MenuComponent, 
    FooterComponent, 
    EntrypointComponent,
    CouponComponent,
    CheckoutComponent,
    CheckoutCouponComponent,
    ResultComponent,
    ViewResultComponent,
    ProductDetailsComponent,
    ProductsComponent,
    ProductItemComponent,
    FilterComponent,
    SearchbarComponent,
    ViewQuizComponent,
    CartComponent,
    PapersComponent,
    PapersTableComponent,
  ],
  entryComponents: [],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicStorageModule.forRoot(),
    IonicModule.forRoot(),
    AppRoutingModule,
    
    BrowserAnimationsModule 
  ],
  providers: [
    StatusBar,
    SplashScreen,
    /*LottieSplashScreen,*/
    CommonService,
    FormBuilder,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    File,
    FileOpener,
    FileTransfer,
    DocumentViewer,
    OneSignal
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}